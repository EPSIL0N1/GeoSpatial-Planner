from flask import Flask, render_template, request
import joblib
import numpy as np
import requests
import random
import pandas as pd



model = joblib.load(open('logistic_regression_model.joblib', 'rb'))
# mlp_mall = joblib.load(open('mlp_mall.joblib', 'rb'))
# mlp_hospital = joblib.load(open('mlp_hospital.joblib', 'rb'))
# mlp_restaurant = joblib.load(open('mlp_restaurant.joblib', 'rb'))
# model_1 = joblib.load(open('random_forest_model.joblib', 'rb'))

app = Flask(__name__)

@app.route("/")

def Home():
        
    return render_template("Home.html")
    # return "hello"
    
@app.route("/Predict_Input", methods=["GET", "POST"])
def Predict_Input():
    
    if request.method == "POST":
        
#         #Deploy ML model here
        location = request.form.get('location')
        infrastructure = request.form.get('infrastructure')
        
        api_key = "AoCvxV8HLQ9lCd_DiK2upRdy6YUwZD_a0W8jHTBU3ZPxuR4vQWgqPYfcbMGflL_5"
#         location_name = location
        
# Query parameters
        params = {
        "q": location,
        "key": api_key,
        }
        
        base_url = "https://dev.virtualearth.net/REST/v1/Locations"
        
        response = requests.get(base_url, params=params)

# Check if the request was successful
        if response.status_code == 200:
            data = response.json()
            if data.get("resourceSets"):
                # Extract and print the geospatial information
                resource_set = data["resourceSets"][0]
                if resource_set.get("resources"):
                    resource = resource_set["resources"][0]
                    coordinates = resource["point"]["coordinates"]
                    latitude, longitude = coordinates
                    # print(f"Location: {location_name}")
                    # print(f"Latitude: {latitude}")
                    Lat = latitude
                    # print(f"Longitude: {longitude}")
                    Lon = longitude
                else:
                    print("No geospatial information found.")
            else:
                print("No resource sets found.")
        else:
            print("Error:", response.status_code)
            print(response.text)





        
        #This is for LINE GRAPH
        
        data1=[(1,random.random()),(2,random.random()),(3,random.random()),(4,random.random()),(5,random.random()),(6,random.random()),(7,random.random()),(8,random.random()),(9,random.random()),(10,random.random()),(11,random.random()),(12,random.random())]
        data = data1
        
        labels = [row[0] for row in data]
        values = [row[1] for row in data]
        
        #This is for testing
    
        response = requests.get(f"http://dev.virtualearth.net/REST/v1/Routes/LocalInsights?waypoint={Lat},{Lon}&optimize=distance&travelMode=driving&maxDistance=1&type=MallsAndShoppingCenters&key={api_key}")

        Mall = response.json()['resourceSets'][0]['resources']
        Mall = str(Mall[0]['categoryTypeResults'][0]['categoryTypeSummary'])
        mall=Mall.split(" ")
        malls=int(mall[0])

        response = requests.get(f"http://dev.virtualearth.net/REST/v1/Routes/LocalInsights?waypoint={Lat},{Lon}&optimize=distance&travelMode=driving&maxDistance=1&type=EatDrink&key={api_key}")

        Restaurant = response.json()['resourceSets'][0]['resources']
        Restaurant = str(Restaurant[0]['categoryTypeResults'][0]['categoryTypeSummary'])
        restaurant=Restaurant.split(" ")
        restaurants=int(restaurant[0])

        response = requests.get(f"http://dev.virtualearth.net/REST/v1/Routes/LocalInsights?waypoint={Lat},{Lon}&optimize=distance&travelMode=driving&maxDistance=1&type=Hospitals&key={api_key}")

        Hospitals = response.json()['resourceSets'][0]['resources']
        Hospitals = str(Hospitals[0]['categoryTypeResults'][0]['categoryTypeSummary'])
        hospital=Hospitals.split(" ")
        hospitals=int(hospital[0])
        
        infra=infrastructure
        
        if(infra=='mall'):
                malls=malls+1
        if(infra=='hospital'):
            hospitals=malls+1
        if(infra=='restaurant'):
            restaurants=malls+1
            
        prob_mall=malls/(malls+hospitals+restaurants)
        prob_hospital=hospitals/(malls+hospitals+restaurants)
        prob_restaurant=restaurants/(malls+hospitals+restaurants)
        
        
        p = model.predict(np.array([Lat,Lon,np.random.randint(0,1),np.random.randint(0,1),np.random.randint(0,1),np.random.randint(0,1)]).reshape(1, 6))
        
        
        #This is for PIE CHART
        
        data_pie = [
            ("Hospital", prob_hospital),
            ("Mall", prob_mall),
            ("Restaurant", prob_restaurant)
            
        ]
        
        labels_pie = [row[0] for row in data_pie]
        values_pie = [row[1] for row in data_pie]
        
        #this is for environmental conservation
        api=(f"https://api.weatherbit.io/v2.0/current?lat={Lat}&lon={Lon}&key=d22d2df883a14d368076dfaf4095af95&include=minutely")
        response = requests.get(api)
        
        data=response.json()
        data = data['data'][0]['aqi']
        
        if data <=100:
            flag="Safe"
            
        else:
            flag="Not Safe"
        
        return render_template("P_Dashboard.html", location=location, infrastructure=infrastructure, labels=labels, values=values, labels_pie=labels_pie, values_pie=values_pie, urban_ratio=p[0], flag=flag, data=data)
        
    
    return render_template("Predict_Input.html")




@app.route("/Suggest_Input", methods=['GET', 'POST'])
def suggest():
    
    if request.method == "POST":
        location = request.form.get('location')
        area = request.form.get('infrastructure')

        api_key = "AoCvxV8HLQ9lCd_DiK2upRdy6YUwZD_a0W8jHTBU3ZPxuR4vQWgqPYfcbMGflL_5"
#         location_name = location
        
# Query parameters
        params = {
        "q": location,
        "key": api_key,
        }
        
        base_url = "https://dev.virtualearth.net/REST/v1/Locations"
        
        response = requests.get(base_url, params=params)

# Check if the request was successful
        if response.status_code == 200:
            data = response.json()
            if data.get("resourceSets"):
                # Extract and print the geospatial information
                resource_set = data["resourceSets"][0]
                if resource_set.get("resources"):
                    resource = resource_set["resources"][0]
                    coordinates = resource["point"]["coordinates"]
                    latitude, longitude = coordinates
                    # print(f"Location: {location_name}")
                    # print(f"Latitude: {latitude}")
                    Lat = latitude
                    # print(f"Longitude: {longitude}")
                    Lon = longitude
                else:
                    print("No geospatial information found.")
            else:
                print("No resource sets found.")
        else:
            print("Error:", response.status_code)
            print(response.text)

        response = requests.get(f"http://dev.virtualearth.net/REST/v1/Routes/LocalInsights?waypoint={Lat},{Lon}&optimize=distance&travelMode=driving&maxDistance=1&type=MallsAndShoppingCenters&key={api_key}")

        Mall = response.json()['resourceSets'][0]['resources']
        Mall = str(Mall[0]['categoryTypeResults'][0]['categoryTypeSummary'])
        mall=Mall.split(" ")
        malls=int(mall[0])

        response = requests.get(f"http://dev.virtualearth.net/REST/v1/Routes/LocalInsights?waypoint={Lat},{Lon}&optimize=distance&travelMode=driving&maxDistance=1&type=EatDrink&key={api_key}")

        Restaurant = response.json()['resourceSets'][0]['resources']
        Restaurant = str(Restaurant[0]['categoryTypeResults'][0]['categoryTypeSummary'])
        restaurant=Restaurant.split(" ")
        restaurants=int(restaurant[0])

        response = requests.get(f"http://dev.virtualearth.net/REST/v1/Routes/LocalInsights?waypoint={Lat},{Lon}&optimize=distance&travelMode=driving&maxDistance=1&type=Hospitals&key={api_key}")

        Hospitals = response.json()['resourceSets'][0]['resources']
        Hospitals = str(Hospitals[0]['categoryTypeResults'][0]['categoryTypeSummary'])
        hospital=Hospitals.split(" ")
        hospitals=int(hospital[0])
        
       
            
        prob_mall=malls/(malls+hospitals+restaurants)
        prob_hospital=hospitals/(malls+hospitals+restaurants)
        prob_restaurant=restaurants/(malls+hospitals+restaurants)
        
        data_pie = [
            ("Hospital", prob_hospital),
            ("Mall", prob_mall),
            ("Restaurant", prob_restaurant)
            
        ]
        
        labels_pie = [row[0] for row in data_pie]
        values_pie = [row[1] for row in data_pie]
        
    
        return render_template("S_Dashboard.html", Lat=Lat, Lon=Lon, labels_pie=labels_pie, values_pie=values_pie)
    return render_template("Suggest_input.html")


@app.route("/document")
def docu():
    return render_template("documentation.html")


app.run(debug=True)


